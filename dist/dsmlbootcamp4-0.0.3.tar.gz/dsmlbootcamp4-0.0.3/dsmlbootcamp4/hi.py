def hello2():
    print("hej hej")

def hello():
    print("hello")
